from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivymd.toast import toast
from kivy.properties import DictProperty, NumericProperty, StringProperty
from kivy.uix.anchorlayout import AnchorLayout  
from kivy.clock import Clock
from kivy.uix.image import Image
#import matplotlib.pyplot as plt

class Progress1(AnchorLayout):
    set_value = NumericProperty(0)
    value = NumericProperty(61)
    counter = NumericProperty(0)
    text = StringProperty("0%")
    duration = NumericProperty(.5)
    
    def __init__(self, **kwargs):
        super(Progress1, self).__init__(**kwargs)
        Clock.schedule_once(self.animate, 0)
        
    def animate(self, *args):
        Clock.schedule_interval(self.percent_counter, self.duration/self.value)
        
    def percent_counter(self, *args):
        if self.counter < self.value:
            self.counter += 1
            self.text = f"{self.counter}%"
            self.set_value = self.counter
        else:
            Clock.unschedule(self.percent_counter)
            
class Progress2(AnchorLayout):
    set_value = NumericProperty(0)
    value = NumericProperty(78)
    counter = NumericProperty(0)
    text = StringProperty("0%")
    duration = NumericProperty(.5)
    
    def __init__(self, **kwargs):
        super(Progress2, self).__init__(**kwargs)
        Clock.schedule_once(self.animate, 0)
        
    def animate(self, *args):
        Clock.schedule_interval(self.percent_counter, self.duration/self.value)
        
    def percent_counter(self, *args):
        if self.counter < self.value:
            self.counter += 1
            self.text = f"{self.counter}%"
            self.set_value = self.counter
        else:
            Clock.unschedule(self.percent_counter)
            
class Home(Screen):
    Builder.load_file("/home/kala/Documents/health/kvfiles/home.kv")
    def __init__(self, **kwargs):
        super(Home, self).__init__(**kwargs)
        #self.on_start()

jk = """ def on_start(self):
        print("on enter")
    # Generate random data for scatter plot
        x = [1, 2, 3, 4, 5, 6, 7]
        y = [3, 6, 5 ,8, 7, 4, 5]

        # Create the plot
        plt.figure(figsize=(10, 10))

        # Plot the data points
        plt.scatter(x, y, label='time ava', color='blue')

        # Plot vertical lines at x=6 and x=8
        plt.axhline(y=9, color='orange', linestyle='-', label='minimum sleeping time')
        plt.axhline(y=6, color='green', linestyle='-', label='maximum sleeping time')
        plt.axhline(y=12, color="red", linestyle='--', label='ubnormal health')

        # Set x and y axis limits
        plt.xlim(0, 8)
        plt.ylim(0, 18)

        # Add labels and legend
        plt.xlabel('days')
        plt.ylabel('time')
        plt.title('last 7 days sleep graph')
        plt.legend()
        plt.plot(x, y)
        # Show the plot
        plt.grid(False)
        plt.savefig("./assets/plot.jpeg")
        self.fit()

    def fit(self):
        self.ids.imfit.source = "./assets/plot.jpeg"
        """