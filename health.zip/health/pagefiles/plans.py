from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.uix.screenmanager import Screen
from kivy.properties import DictProperty
from kivymd.uix.behaviors import TouchBehavior 
from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.boxlayout import MDBoxLayout
from datetime import datetime
from kivymd.uix.label import MDLabel
from kivy.core.window import Window

class MsgCard(MDCard, TouchBehavior):
    def on_long_touch(self, *args):
        self.remove_card()
        
    def remove_card(self):
        dialog = MDDialog(title="Delete data", text=f"Are you sure? delete this plan?", 
                          buttons=[ 
                                MDRaisedButton(text="Cancel", on_release=lambda x: self.dialog.dismiss() if self.dialog else None), 
                                MDRaisedButton(text="Delete", on_release=lambda x: self.do_remove_card())
                                ],)
        dialog.open()
        self.dialog = dialog

    def do_remove_card(self):
        self.parent.remove_widget(self)
        if self.dialog:
            self.dialog.dismiss()
        
class Content(BoxLayout):
    pass

class Plans(Screen):
    Builder.load_file("/home/kala/Documents/health/kvfiles/plans.kv")
    data = DictProperty()
    dialog = None
    def __init__(self, **kwargs):
        super(Plans, self).__init__(**kwargs)
        self.data = {
            '''  add  ''' : ['plus', "on_press", lambda x: self.add_dialog()], 
            '''  delete  ''': ['delete', "on_press", lambda x: self.pens(),], 
            '''  details ''': ['details', "on_press", lambda x: self.pens(),]
            }  
        
    def file(self):
        print("file pressed")
        
    def cat(self):
        print("cat pressed")
        
    def pencil(self):
        print("pencil pressed")
        
    #_____start_____floating_button_icons_test
    def pens(self):
        from datetime import datetime
        time = datetime.now()
        self.value =f"{(time.strftime('%I.%M %p'))}"
        return self.value
        
    def files(self, card, touch):
        print(" OK files get!")    
        
#_____end_____floating_button_icons_test
#_____start_____plans_adding_process    
    def add_dialog(self):
        content_cls = Content()
        if not self.dialog:
            self.dialog = MDDialog(title="Add your mindset", text="Your current mindset type here",type="custom", content_cls = content_cls, auto_dismiss = False, radius = [50, 10, 50, 10], 
                                   buttons=[ 
                                            MDFlatButton(text="CANCEL", theme_text_color="Custom", text_color=(1,.5,.5), on_release = self.dialog_close), 
                                            MDFlatButton(text="OK", theme_text_color="Custom", text_color= (1,.5,.5), on_release = lambda x:self.valgeting(x, content_cls)),
                                            ],
                                   )
        self.dialog.open()
        
    def dialog_close(self, *args):
        self.dialog.dismiss(force=True)
        
    def valgeting(self, intense_btn, content_cls):
        self.textv = content_cls.ids.textf
        self.vals = self.textv._get_text()
        self.textv.text = ""
        self.adding(self.vals)
        self.dialog_close()
        
    def adding(self, mes):
        self.time = self.pens()
        self.mes = mes
        if len(self.mes) < 70:
            self.mes
        elif len(self.mes) > 70:
            self.mes = f"{self.mes[:65]}...."
        #__card__create__start
        card = MsgCard(size_hint=(None, None), width=Window.width / 10 * 7, height=Window.width / 10 * 3, md_bg_color=(255/255, 230/255, 252/255, .6), radius=[25], elevation=.6, style="outlined")
        box_layout = MDBoxLayout(orientation="vertical")
        label_text = MDLabel(text= self.mes, theme_text_color="Custom", text_color=(54/255, 1/255, 63/255),halign="center")   
        label_time = MDLabel(text=self.time, font_style= "Overline", halign="center")
        box_layout.add_widget(label_text)
        box_layout.add_widget(label_time)
        card.add_widget(box_layout)
        card.id = str(card.uid)
        self.ids.tom.add_widget(card, index=0, canvas=None)
        #__card__create__end
#_____end_____plans_adding_process