from kivymd.app import MDApp
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen, NoTransition
from kivymd.uix.button import MDFloatingActionButtonSpeedDial
from kivymd.toast import toast
from kivy.properties import DictProperty, NumericProperty, StringProperty
from kivy.uix.anchorlayout import AnchorLayout  
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.behaviors import TouchBehavior 
import json
from datetime import datetime
#from kivy.core.text import LabelBase

#LabelBase.register("custom_font", fn_regular="newpyfolder/ttffiles/pop11.ttf")

class Manage(ScreenManager):
    pass
class Home(Screen):
    pass
class Sct(Screen):
    pass
  
class MsgCard(MDCard, TouchBehavior):
    def on_long_touch(self, *args):
        self.remove_card()
        
    def remove_card(self):
        dialog = MDDialog(title="Delete data", text=f"Are you sure? delete this plan?", buttons=[ MDRaisedButton(text="Cancel", on_release=lambda x: self.dialog.dismiss() if self.dialog else None), MDRaisedButton(text="Delete", on_release=lambda x: self.do_remove_card())],)
        dialog.open()
        self.dialog = dialog

    def do_remove_card(self):
        self.parent.remove_widget(self)
        if self.dialog:
            self.dialog.dismiss()
        
class Content(BoxLayout):
    pass
       
#_____start_____circular_progress_bar_code        
class Progress(AnchorLayout):
    set_value = NumericProperty(0)
    value = NumericProperty(82)
    counter = NumericProperty(0)
    text = StringProperty("0%")
    duration = NumericProperty(.5)
    
    def __init__(self, **kwargs):
        super(Progress, self).__init__(**kwargs)
        Clock.schedule_once(self.animate, 0)
        
    def animate(self, *args):
        Clock.schedule_interval(self.percent_counter, self.duration/self.value)
        
    def percent_counter(self, *args):
        if self.counter < self.value:
            self.counter += 1
            self.text = f"{self.counter}%"
            self.set_value = self.counter
        else:
            Clock.unschedule(self.percent_counter)
#_____end_____circular_progress_bar_code
#_____start_____base_build
class Pages(MDApp):
    #__floatingButton__icons
    data = DictProperty()
    #file = open('detailsper.json')
    #datas = json.load(file)
    dialog = None
    #__dialog,file_open__

    def build(self):
        self.file = Builder.load_file("kivtest1.kv")
        self.theme_cls.theme_style = "Light"
        self.theme_cls.primary_palette = "DeepPurple"
        self.theme_cls.primary_light_hue = "A700"  
        #__start__floating_button_properties
        self.data = {'''  add  ''' : ['plus', "on_press", lambda x: self.add_dialog()], '''  delete  ''': ['delete', "on_press", lambda x: self.pens(),], '''  details ''': ['details', "on_press", lambda x: self.pens(),]} 
        #__end__floating_button_properties
        return self.file
#_____end_____base_build
#_____start_____floating_button_icons_test
    def pens(self):
        from datetime import datetime
        time = datetime.now()
        self.value =f"{(time.strftime('%I.%M %p'))}"
        return self.value
        
    def files(self, card, touch):
        print(" OK files get!")    
        
#_____end_____floating_button_icons_test
#_____start_____plans_adding_process    
    def add_dialog(self):
        content_cls = Content()
        if not self.dialog:
            self.dialog = MDDialog(title="Add your mindset", text="Your current mindset type here",type="custom", content_cls = content_cls, auto_dismiss = False, radius = [50, 10, 50, 10], buttons=[ MDFlatButton(text="CANCEL", theme_text_color="Custom", text_color=self.theme_cls.primary_color, on_release = self.dialog_close), MDFlatButton(text="OK", theme_text_color="Custom", text_color=self.theme_cls.primary_color, on_release = lambda x:self.valgeting(x, content_cls)),],)
        self.dialog.open()
        
    def dialog_close(self, *args):
        self.dialog.dismiss(force=True)
        
    def valgeting(self, intense_btn, content_cls):
        self.textv = content_cls.ids.textf
        self.vals = self.textv._get_text()
        self.textv.text = ""
        self.adding(self.vals)
        self.dialog_close()
        
    def adding(self, mes):
        self.time = self.pens()
        self.mes = mes
        if len(self.mes) < 70:
            self.mes
        elif len(self.mes) > 70:
            self.mes = f"{self.mes[:65]}...."
        #__card__create__start
        card = MsgCard(size_hint=(None, None), width=self.root.width / 10 * 7, height=self.root.width / 10 * 3, md_bg_color=(255/255, 230/255, 252/255, .6), radius=[25], elevation=.6, style="outlined")
        box_layout = MDBoxLayout(orientation="vertical")
        label_text = MDLabel( text= self.mes, theme_text_color="Custom", text_color=(54/255, 1/255, 63/255),halign="center")   
        label_time = MDLabel(text=self.time, font_style= "Overline", halign="center")
        box_layout.add_widget(label_text)
        box_layout.add_widget(label_time)
        card.add_widget(box_layout)
        card.id = str(card.uid)
        self.root.get_screen('home').ids.tom.add_widget(card, index=0, canvas=None)
        #__card__create__end
#_____end_____plans_adding_process

if __name__ == "__main__":
    Pages().run()