from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.uix.screenmanager import Screen

class Game(Screen):
    Builder.load_file("/home/kala/Documents/health/kvfiles/game.kv")
    def __init__(self, **kwargs):
        super(Game, self).__init__(**kwargs)
        pass