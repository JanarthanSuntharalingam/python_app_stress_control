#a = int(input("enter first number : "))
#b = int(input("enter second number : "))

#x = int(input("enter select : "))

#if x == 1:
#    print(a+b)
#elif x == 2:
#    print(a-b)
#elif x == 3: 
#    print(a*b)
#elif x == 4:
#    print(a/b) 
#else:
#    print("incorrect option")
d = 0
c = 0
while (d==0):
    b = int(input("any number : "))
    a = c
    x = int(input("any"))
    if x == 1:
        c = a+b
        print(a+b)
    elif x == 2:
        c = a-b
        print(a-b)
    elif x == 3:
        c = a*b 
        print(a*b)
    elif x == 4:
        c = a/b
        print(a/b) 
    else:
        d = 1