from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.uix.screenmanager import ScreenManager, Screen, NoTransition
from kivymd.toast import toast
from kivy.uix.anchorlayout import AnchorLayout  
from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.fitimage import FitImage
import os
from kivymd.uix.behaviors import TouchBehavior 
from kivy.core.window import Window

fwidth = Window.width
fheight = Window.height

class PosImgCard(MDCard, TouchBehavior):
    def on_long_touch(self, *args):
        print("clicked", *args)
        
class NegImgCard(MDCard, TouchBehavior):
    def on_long_touch(self, *args):
        print("clicked", *args)

class Emoji(Screen):
    Builder.load_file("/home/kala/Documents/health/kvfiles/emoji.kv")
    def __init__(self, **kwargs):
        super(Emoji, self).__init__(**kwargs)
        self.on_start()

    def getting_atr(self, *args):
        print("print  ", *args)
        
    # whole program start first run default function
    def on_start(self):
        self.pos_em_load()
        self.neg_em_load()
        
    def pos_em_load(self):
        self.lists = os.listdir("/home/kala/Documents/health/assets/emojis/positive/")
        for i in range(36):
            cards = PosImgCard(size_hint = (None, None), width = fwidth/10*.5, height = fwidth/10*.5, radius = [10], md_bg_color = ("purple"), id = f"p{i}", on_press = self.getting_atr)
            cards.add_widget(FitImage(source = f"/home/kala/Documents/health/assets/emojis/positive/{self.lists[i]}", radius = [20]))       
            self.ids.emp.add_widget(cards)
                 
    def neg_em_load(self):
        self.lists = os.listdir("/home/kala/Documents/health/assets/emojis/negative/")
        for i in range(14):
            cards = NegImgCard(size_hint = (None, None), width = fwidth/10*.5, height = fwidth/10*.5, radius = [10], md_bg_color = ("purple"), on_press = self.getting_atr)
            cards.add_widget(FitImage(source = f"/home/kala/Documents/health/assets/emojis/negative/{self.lists[i]}", radius = [20]))     
            self.ids.emn.add_widget(cards)