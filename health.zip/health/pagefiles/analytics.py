from kivy.lang import Builder
from kivymd.app import MDApp
from kivy.uix.screenmanager import Screen

class Analytics(Screen):
    Builder.load_file("/home/kala/Documents/health/kvfiles/analytics.kv")
    def __init__(self, **kwargs):
        super(Analytics, self).__init__(**kwargs)
        pass