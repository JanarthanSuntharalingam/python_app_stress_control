import json

def add(id, plans, date, time, state):
    pass

def delete(id, state):
    pass

def emoji(id, emoji, date, time, state):
    pass